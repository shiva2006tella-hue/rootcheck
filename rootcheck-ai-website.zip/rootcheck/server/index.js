import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(cors());
app.use(express.json({limit:"1mb"}));

function demo(claim){
  const lower=claim.toLowerCase();
  const health=/testosterone|cancer|vitamin|supplement|cold shower|detox|memory|weight|blood|disease|health/.test(lower);
  const viral=/50%|90%|10x|guarantee|everyone|always|never|proven/.test(lower);
  const score=Math.max(38,Math.min(91,82-(health?10:0)-(viral?18:0)));
  return {
    claim,score,confidence:86,
    verdict:score>=75?"Mostly supported":"Needs caution",
    summary:score>=75?"The claim has a plausible evidence path, but the original source and context still matter.":"The claim shows signs of evidence compression: repeated wording, weak provenance, or an unusually strong conclusion.",
    metrics:{freshness:score-2,primary:Math.max(35,score-7),independence:Math.max(32,score-14)},
    sources:[
      {type:"SECONDARY",title:"Claim reproduced across multiple web sources",detail:"Repetition is not independent confirmation. Trace each citation to its underlying document.",year:"2024–2026",domain:"web sources",status:"citation loop possible",score:score-16,flag:"Several pages may echo the same statistic."},
      {type:"PRIMARY",title:health?"Underlying study / research record":"Original research or dataset",detail:"Inspect the actual study or dataset rather than relying on summaries or press releases.",year:"Varies",domain:"primary literature",status:"needs verification",score:score-7,flag:"Design and population matter before generalizing."},
      {type:"CONTEXT",title:"Independent corroboration",detail:"Check replication, systematic reviews, contradictory findings, and whether the result holds outside the original context.",year:"Recent",domain:"review layer",status:"context check",score:score-19,flag:"No single source should be treated as definitive."}
    ],
    signals:[
      {level:viral?"bad":"warn",title:"Evidence compression",text:"The claim is stronger and cleaner than the evidence trail usually is.",delta:"−12"},
      {level:"warn",title:"Independence",text:"Repeated citations may not represent independent underlying research.",delta:"−8"},
      {level:"good",title:"Traceability",text:"A primary-source path is identifiable for deeper review.",delta:"+9"}
    ],
    recommendation:score>=75?{level:"good",icon:"✓",title:"Repeat with context",text:"Use the underlying source and avoid upgrading correlation into causation."}:{level:"bad",icon:"!",title:"Do not repeat as fact",text:"Find and inspect the primary evidence before publishing, citing, or making a strong claim."}
  };
}

app.post("/api/analyze", async (req,res)=>{
  const claim=String(req.body?.claim||"").trim();
  if(!claim) return res.status(400).json({error:"claim required"});

  // Optional live LLM layer. Keep the app functional without credentials.
  if(process.env.AI_API_URL && process.env.AI_API_KEY){
    try{
      const response=await fetch(process.env.AI_API_URL,{
        method:"POST",
        headers:{"Content-Type":"application/json","Authorization":`Bearer ${process.env.AI_API_KEY}`},
        body:JSON.stringify({
          model:process.env.AI_MODEL || "gpt-4.1-mini",
          input:`Analyze this claim as a source-decay researcher. Return ONLY valid JSON matching this shape:
{"claim":string,"score":number,"confidence":number,"verdict":string,"summary":string,"metrics":{"freshness":number,"primary":number,"independence":number},"sources":[{"type":string,"title":string,"detail":string,"year":string,"domain":string,"status":string,"score":number,"flag":string}],"signals":[{"level":"good|warn|bad","title":string,"text":string,"delta":string}],"recommendation":{"level":"good|bad","icon":string,"title":string,"text":string}}
Do not invent URLs, papers, authors, or retractions. If live source retrieval is unavailable, say so in the result.
CLAIM: ${claim}`
        })
      });
      if(response.ok){
        const data=await response.json();
        const text=data.output_text || data.output?.[0]?.content?.[0]?.text;
        if(text) return res.json(JSON.parse(text));
      }
    }catch(e){ console.warn("AI provider failed; using local fallback.",e.message); }
  }
  res.json(demo(claim));
});

app.use(express.static(path.join(__dirname,"../public")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"../index.html")));
const port=process.env.PORT||8787;
app.listen(port,()=>console.log(`Rootcheck running on http://localhost:${port}`));
