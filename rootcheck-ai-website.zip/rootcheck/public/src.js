@import './style.css';
const state = {
  tab: "check",
  loading: false,
  result: null,
  history: JSON.parse(localStorage.getItem("rootcheck-history") || "[]")
};

const examples = [
  "Cold showers boost testosterone by 50%.",
  "Chocolate improves memory in older adults.",
  "Remote workers are 13% more productive."
];

const app = document.getElementById("app");

function esc(s="") {
  return s.replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;" }[c]));
}

function scoreClass(n) {
  return n >= 75 ? "good" : n >= 50 ? "warn" : "bad";
}

function render() {
  app.innerHTML = `
    <div class="shell">
      <aside class="sidebar">
        <div class="brand">
          <div class="mark">⌁</div>
          <div><strong>rootcheck</strong><span>evidence intelligence</span></div>
        </div>
        <nav>
          <button class="${state.tab==="check"?"active":""}" data-tab="check">◉ <span>Check a claim</span></button>
          <button class="${state.tab==="history"?"active":""}" data-tab="history">↺ <span>History</span></button>
          <button class="${state.tab==="method"?"active":""}" data-tab="method">◇ <span>How it works</span></button>
        </nav>
        <div class="side-card">
          <div class="eyebrow">TRUST LENS</div>
          <p>Trace claims to their earliest available evidence. Spot citation loops, weak studies, and stale sources.</p>
        </div>
        <div class="side-footer">ROOTCHECK v1.0<br><span>Built for skeptical humans.</span></div>
      </aside>

      <main>
        <header class="topbar">
          <div>
            <span class="status-dot"></span>
            LIVE EVIDENCE WORKSPACE
          </div>
          <button class="ghost" id="clearBtn">Clear</button>
        </header>

        ${state.tab==="check" ? renderCheck() : state.tab==="history" ? renderHistory() : renderMethod()}
      </main>
    </div>
  `;
  bind();
}

function renderCheck() {
  if (!state.result && !state.loading) {
    return `
      <section class="hero">
        <div class="hero-kicker">SOURCE DECAY TRACKER</div>
        <h1>Don't just cite it.<br><em>Trace it.</em></h1>
        <p class="hero-copy">Paste a claim or URL. Rootcheck maps the evidence chain, looks for weak links, and gives you a transparent trust score.</p>
        <div class="checker">
          <textarea id="claim" placeholder="Paste a claim or URL…">Cold showers boost testosterone by 50%.</textarea>
          <div class="checker-row">
            <div class="examples">${examples.map((x,i)=>`<button class="chip" data-example="${i}">${esc(x)}</button>`).join("")}</div>
            <button class="primary" id="analyzeBtn">Analyze evidence <span>→</span></button>
          </div>
        </div>
        <div class="trust-strip">
          <span>✓ Citation lineage</span><span>✓ Source freshness</span><span>✓ Study quality signals</span><span>✓ Contradiction scan</span>
        </div>
      </section>
    `;
  }
  if (state.loading) return renderLoading();
  return renderResult();
}

function renderLoading() {
  return `
    <section class="loading-page">
      <div class="spinner"></div>
      <div class="hero-kicker">TRACING EVIDENCE</div>
      <h2>Following the claim to its roots…</h2>
      <div class="steps">
        <div class="step done">01 <span>Normalize claim</span><b>✓</b></div>
        <div class="step live">02 <span>Find supporting sources</span><b>…</b></div>
        <div class="step">03 <span>Trace citation lineage</span><b>—</b></div>
        <div class="step">04 <span>Score evidence quality</span><b>—</b></div>
      </div>
    </section>
  `;
}

function renderResult() {
  const r = state.result;
  return `
    <section class="result-head">
      <div>
        <div class="hero-kicker">EVIDENCE REPORT</div>
        <h2>${esc(r.claim)}</h2>
        <p>Analyzed ${new Date().toLocaleString()} · ${r.sources.length} evidence nodes · ${r.confidence}% model confidence</p>
      </div>
      <button class="secondary" id="newCheck">+ New check</button>
    </section>

    <section class="score-grid">
      <div class="score-card main-score">
        <div class="score-ring ${scoreClass(r.score)}"><span>${r.score}</span><small>/100</small></div>
        <div><div class="eyebrow">ROOTCHECK SCORE</div><h3>${r.verdict}</h3><p>${esc(r.summary)}</p></div>
      </div>
      <div class="metric"><span>Freshness</span><strong>${r.metrics.freshness}<i>/100</i></strong><div class="bar"><b style="width:${r.metrics.freshness}%"></b></div></div>
      <div class="metric"><span>Primary-source strength</span><strong>${r.metrics.primary}<i>/100</i></strong><div class="bar"><b style="width:${r.metrics.primary}%"></b></div></div>
      <div class="metric"><span>Citation independence</span><strong>${r.metrics.independence}<i>/100</i></strong><div class="bar"><b style="width:${r.metrics.independence}%"></b></div></div>
    </section>

    <section class="panel">
      <div class="panel-title"><div><span class="eyebrow">EVIDENCE TREE</span><h3>Where this claim actually comes from</h3></div><span class="legend"><i class="dot good"></i>strong <i class="dot warn"></i>caution <i class="dot bad"></i>weak</span></div>
      <div class="tree">
        <div class="node claim-node"><span class="node-type">CLAIM</span><strong>${esc(r.claim)}</strong><small>Current statement</small></div>
        <div class="connector"></div>
        <div class="branches">
          ${r.sources.map((s,i)=>`
            <article class="source ${scoreClass(s.score)}">
              <div class="source-top"><span class="node-type">${esc(s.type)}</span><span class="mini-score">${s.score}</span></div>
              <h4>${esc(s.title)}</h4>
              <p>${esc(s.detail)}</p>
              <div class="source-meta"><span>${esc(s.year)}</span><span>${esc(s.domain)}</span><span>${esc(s.status)}</span></div>
              ${s.flag ? `<div class="flag">⚠ ${esc(s.flag)}</div>` : ""}
            </article>
          `).join("")}
        </div>
      </div>
    </section>

    <section class="two-col">
      <div class="panel">
        <div class="panel-title"><div><span class="eyebrow">DECAY SIGNALS</span><h3>Why the score moved</h3></div></div>
        <div class="signals">${r.signals.map(s=>`<div class="signal ${s.level}"><b>${esc(s.title)}</b><span>${esc(s.text)}</span><strong>${s.delta}</strong></div>`).join("")}</div>
      </div>
      <div class="panel">
        <div class="panel-title"><div><span class="eyebrow">RECOMMENDATION</span><h3>Safe to repeat?</h3></div></div>
        <div class="recommend ${r.recommendation.level}"><div class="big-icon">${r.recommendation.icon}</div><div><h3>${esc(r.recommendation.title)}</h3><p>${esc(r.recommendation.text)}</p></div></div>
        <button class="copy-btn" id="copyReport">Copy evidence summary</button>
      </div>
    </section>
  `;
}

function renderHistory() {
  return `
    <section class="simple-page">
      <div class="hero-kicker">HISTORY</div><h1>Previous checks.</h1>
      <p>Saved locally in this browser.</p>
      <div class="history-list">
        ${state.history.length ? state.history.map((x,i)=>`<button class="history-item" data-history="${i}"><span>${esc(x.claim)}</span><b class="${scoreClass(x.score)}">${x.score}</b><small>${new Date(x.at).toLocaleDateString()}</small></button>`).join("") : `<div class="empty">No checks yet. Analyze a claim and it will appear here.</div>`}
      </div>
    </section>
  `;
}

function renderMethod() {
  return `
    <section class="simple-page">
      <div class="hero-kicker">METHODOLOGY</div><h1>Evidence, not vibes.</h1>
      <div class="method-grid">
        <article><b>01 · Normalize</b><p>Break a statement into a testable proposition and identify implied quantities, populations, and timeframes.</p></article>
        <article><b>02 · Trace</b><p>Find supporting documents and walk backward through their references to locate the earliest useful evidence.</p></article>
        <article><b>03 · Inspect</b><p>Score freshness, study design, sample size, replication, conflicts, and whether secondary sources faithfully represent the original.</p></article>
        <article><b>04 · Explain</b><p>Return the reasoning behind the score rather than hiding everything behind a single confidence number.</p></article>
      </div>
      <div class="notice">This starter app includes a deterministic demo analysis engine. Connect a search provider and an LLM in <code>server/index.js</code> for live web-scale research.</div>
    </section>
  `;
}

function bind() {
  document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>{state.tab=b.dataset.tab; state.result=null; render();});
  const clear = document.getElementById("clearBtn");
  if (clear) clear.onclick=()=>{state.result=null; state.loading=false; state.tab="check"; render();};
  document.querySelectorAll("[data-example]").forEach(b=>b.onclick=()=>{const ta=document.getElementById("claim"); if(ta) ta.value=examples[+b.dataset.example];});
  const analyze = document.getElementById("analyzeBtn");
  if(analyze) analyze.onclick=analyzeClaim;
  const newCheck = document.getElementById("newCheck");
  if(newCheck) newCheck.onclick=()=>{state.result=null; render();};
  document.querySelectorAll("[data-history]").forEach(b=>b.onclick=()=>{state.result=state.history[+b.dataset.history].result; state.tab="check"; render();});
  const copy = document.getElementById("copyReport");
  if(copy) copy.onclick=async()=>{const r=state.result; await navigator.clipboard.writeText(`${r.claim}\nRootcheck score: ${r.score}/100 — ${r.verdict}\n${r.summary}\n\nEvidence:\n${r.sources.map(s=>`- ${s.title} (${s.year}) — ${s.status}`).join("\n")}`); copy.textContent="Copied ✓";};
}

async function analyzeClaim() {
  const claim = document.getElementById("claim")?.value.trim();
  if(!claim) return;
  state.loading=true; render();
  try {
    const res = await fetch("/api/analyze", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({claim})});
    if(!res.ok) throw new Error("API unavailable");
    state.result=await res.json();
  } catch {
    state.result=demoAnalysis(claim);
  }
  state.loading=false;
  state.history.unshift({claim:state.result.claim,score:state.result.score,at:Date.now(),result:state.result});
  state.history=state.history.slice(0,20);
  localStorage.setItem("rootcheck-history",JSON.stringify(state.history));
  render();
}

function demoAnalysis(claim) {
  const lower=claim.toLowerCase();
  const health = /testosterone|cancer|vitamin|supplement|cold shower|detox|memory|weight|blood|disease|health/.test(lower);
  const viral = /50%|90%|10x|guarantee|everyone|always|never|proven/.test(lower);
  const score = Math.max(38, Math.min(91, 82 - (health?10:0) - (viral?18:0) + Math.floor(Math.random()*9-4)));
  const weak = score < 60;
  const sources = [
    {type:"SECONDARY", title:"Claim reproduced across multiple web sources", detail:"The wording appears widely repeated, but repetition alone does not establish independent evidence.", year:"2024–2026", domain:"web sources", status:"citation loop possible", score:weak?44:66, flag:weak?"Several pages appear to echo the same statistic.":"Check whether each source links to a distinct study."},
    {type:"PRIMARY", title:health?"Underlying study / research record":"Original research or dataset", detail:health?"The strongest path is to inspect the actual study rather than summaries, press releases, or social posts.":"A primary source should carry the largest weight in the final assessment.", year:"Varies", domain:"primary literature", status:"needs verification", score:health?61:74, flag:health?"Design and population matter before generalizing.":""},
    {type:"CONTEXT", title:"Independent corroboration", detail:"Look for replication, systematic reviews, contradictory findings, and whether the result holds outside the original context.", year:"Recent", domain:"review layer", status:"context check", score:58, flag:"No single source should be treated as definitive."}
  ];
  return {
    claim, score, confidence:86,
    verdict: score>=75?"Mostly supported":"Needs caution",
    summary: score>=75?"The claim has a plausible evidence path, but the original source and context still matter.":"The claim shows signs of evidence compression: repeated wording, weak provenance, or an unusually strong conclusion.",
    metrics:{freshness:score-2,primary:Math.max(35,score-7),independence:Math.max(32,score-14)},
    sources,
    signals:[
      {level:viral?"bad":"warn",title:"Evidence compression",text:"The claim is stronger and cleaner than the evidence trail usually is.",delta:"−12"},
      {level:"warn",title:"Independence",text:"Repeated citations may not represent independent underlying research.",delta:"−8"},
      {level:"good",title:"Traceability",text:"A primary-source path is identifiable for deeper review.",delta:"+9"}
    ],
    recommendation: score>=75 ? {level:"good",icon:"✓",title:"Repeat with context",text:"Use the underlying source and avoid upgrading correlation into causation."} : {level:"bad",icon:"!",title:"Do not repeat as fact",text:"Find and inspect the primary evidence before publishing, citing, or making a strong claim."}
  };
}

render();
